python query.py ./index_tables queryfile.txt bm25 single ./result -c1 2
python query.py ./index_tables queryfile.txt bm25 single ./result -c1 3
python query.py ./index_tables queryfile.txt bm25 single ./result -c2 2
python query.py ./index_tables queryfile.txt bm25 single ./result -c2 3
python query.py ./index_tables queryfile.txt bm25 stem ./result -c1 2
python query.py ./index_tables queryfile.txt bm25 stem ./result -c1 3
